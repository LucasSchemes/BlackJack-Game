
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "playwindow.h"
#include <iostream>
#include <cstdlib>
#include <string>
#include <QDebug>
#include <QList>
#include <map>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btn1_clicked()
{
    ui->im1->hide();
    ui->im2->hide();
    ui->btn1->hide();

    playwindow = new PlayWindow(this);
    playwindow->show();
    this->hide();


}



