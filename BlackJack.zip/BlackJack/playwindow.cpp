#include "playwindow.h"
#include "ui_playwindow.h"
#include <iostream>
#include <cstdlib>
#include <string>
#include <QDebug>
#include <QList>
#include <map>

PlayWindow::PlayWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::PlayWindow)
{
    ui->setupUi(this);
    cardsList();
}

PlayWindow::~PlayWindow()
{
    delete ui;
}
//variaveis de valores para representar no programa
static int scoreplayer = 0;
static int scoredealer = 0;
int dealerwins = 0;
int playerwins = 0;
int playerCardCount = 1;
int dealerCardCount = 1;
int cardValues[52] = {1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10};

void PlayWindow::cardsList(){


   //clear na lista
    cardHolder.clear();



    QPixmap card1(":/114.gif");
    QPixmap card2(":/102.gif");
    QPixmap card3(":/103.gif");
    QPixmap card4(":/104.gif");
    QPixmap card5(":/105.gif");
    QPixmap card6(":/106.gif");
    QPixmap card7(":/107.gif");
    QPixmap card8(":/108.gif");
    QPixmap card9(":/109.gif");
    QPixmap card10(":/110.gif");
    QPixmap card11(":/111.gif");
    QPixmap card12(":/112.gif");
    QPixmap card13(":/113.gif");



    QPixmap card14(":/214.gif");
    QPixmap card15(":/202.gif");
    QPixmap card16(":/203.gif");
    QPixmap card17(":/204.gif");
    QPixmap card18(":/205.gif");
    QPixmap card19(":/206.gif");
    QPixmap card20(":/207.gif");
    QPixmap card21(":/208.gif");
    QPixmap card22(":/209.gif");
    QPixmap card23(":/210.gif");
    QPixmap card24(":/211.gif");
    QPixmap card25(":/212.gif");
    QPixmap card26(":/213.gif");


    QPixmap card27(":/314.gif");
    QPixmap card28(":/302.gif");
    QPixmap card29(":/303.gif");
    QPixmap card30(":/304.gif");
    QPixmap card31(":/305.gif");
    QPixmap card32(":/306.gif");
    QPixmap card33(":/307.gif");
    QPixmap card34(":/308.gif");
    QPixmap card35(":/309.gif");
    QPixmap card36(":/310.gif");
    QPixmap card37(":/311.gif");
    QPixmap card38(":/312.gif");
    QPixmap card39(":/313.gif");




    QPixmap card40(":/414.gif");
    QPixmap card41(":/402.gif");
    QPixmap card42(":/403.gif");
    QPixmap card43(":/404.gif");
    QPixmap card44(":/405.gif");
    QPixmap card45(":/406.gif");
    QPixmap card46(":/407.gif");
    QPixmap card47(":/408.gif");
    QPixmap card48(":/409.gif");
    QPixmap card49(":/410.gif");
    QPixmap card50(":/411.gif");
    QPixmap card51(":/412.gif");
    QPixmap card52(":/413.gif");

    //aderir as cartas ao vetor
    cardHolder.append(card1);
    cardHolder.append(card2);
    cardHolder.append(card3);
    cardHolder.append(card4);
    cardHolder.append(card5);
    cardHolder.append(card6);
    cardHolder.append(card7);
    cardHolder.append(card8);
    cardHolder.append(card9);
    cardHolder.append(card10);
    cardHolder.append(card11);
    cardHolder.append(card12);
    cardHolder.append(card13);


    cardHolder.append(card14);
    cardHolder.append(card15);
    cardHolder.append(card16);
    cardHolder.append(card17);
    cardHolder.append(card18);
    cardHolder.append(card19);
    cardHolder.append(card20);
    cardHolder.append(card21);
    cardHolder.append(card22);
    cardHolder.append(card23);
    cardHolder.append(card24);
    cardHolder.append(card25);
    cardHolder.append(card26);


    cardHolder.append(card27);
    cardHolder.append(card28);
    cardHolder.append(card29);
    cardHolder.append(card30);
    cardHolder.append(card31);
    cardHolder.append(card32);
    cardHolder.append(card33);
    cardHolder.append(card34);
    cardHolder.append(card35);
    cardHolder.append(card36);
    cardHolder.append(card37);
    cardHolder.append(card38);
    cardHolder.append(card39);


    cardHolder.append(card40);
    cardHolder.append(card41);
    cardHolder.append(card42);
    cardHolder.append(card43);
    cardHolder.append(card44);
    cardHolder.append(card45);
    cardHolder.append(card46);
    cardHolder.append(card47);
    cardHolder.append(card48);
    cardHolder.append(card49);
    cardHolder.append(card50);
    cardHolder.append(card51);
    cardHolder.append(card52);
    ui->playagainbtn->hide();
    ui->quitbtn->hide();
    ui->restartbtn->hide();
}


void PlayWindow::on_getcardsbtn_clicked()
{

        //gerar numero aleatorio, diminuindo esse valor por 1 e somando o valor da carta à pontuação do jogador
        int number = rand() % 52 + 1;
        scoreplayer += cardValues[number-1];
        ui->totalLabel->setText("Total: " + QString::number(scoreplayer));

        //posição das cartas

        switch(playerCardCount){
        case 1:
            ui->card1Label->setPixmap(cardHolder.at(number - 1));
            break;
        case 2:
            ui->card2Label->setPixmap(cardHolder.at(number - 1));
            break;
        case 3:
            ui->card3Label->setPixmap(cardHolder.at(number - 1));
            break;
        case 4:
            ui->card4Label->setPixmap(cardHolder.at(number - 1));
            break;
        case 5:
            ui->card5Label->setPixmap(cardHolder.at(number - 1));
            ui->getcardsbtn->hide();
            ui->standbtn->hide();


            break;


        }

        // adicionar carta
        ++playerCardCount;
        if (scoreplayer > 21 || playerCardCount==6){

            ui->getcardsbtn->setEnabled(false);

            //Generating Computer score
            dealerTurn();
        }
}
void PlayWindow::dealerTurn(){

    while (scoredealer < 16){
        int number2 = rand() % 52 + 1;
        scoredealer += cardValues[number2-1];

        ui->dealerScoreLabel->setText("Total: " + QString::number(scoredealer));

        switch(dealerCardCount){
        case 1:
            ui->card6Label->setPixmap(cardHolder.at(number2 - 1));
            break;
        case 2:
            ui->card7Label->setPixmap(cardHolder.at(number2- 1));
            break;
        case 3:
            ui->card8Label->setPixmap(cardHolder.at(number2 - 1));
            break;
        case 4:
            ui->card9Label->setPixmap(cardHolder.at(number2 - 1));
            break;
        case 5:
            ui->card10Label->setPixmap(cardHolder.at(number2 - 1));

            break;
        }

        ++dealerCardCount;
    }

    QPixmap win(":/win.png");
    QPixmap lose(":/lose.png");
    QPixmap draw(":/draw.png");

    if ((scoredealer == scoreplayer) || ((scoredealer > 21) && (scoreplayer > 21))){
       ui->resultLabel->setPixmap(draw);
        ui->getcardsbtn->hide();
        ui->standbtn->hide();
        ui->playagainbtn->show();
    }
    //derrota
    else if (((scoredealer < 22) && (scoreplayer < 22) && (scoredealer > scoreplayer)) || ((scoreplayer > 21) && scoredealer < 22 )){
        ui->resultLabel->setPixmap(lose);
        ui->playagainbtn->show();
        ui->getcardsbtn->hide();
        ui->standbtn->hide();
        ++dealerwins;
    }
     //vitoria
   else{
        ui->resultLabel->setPixmap(win);
        ui->playagainbtn->show();
        ui->getcardsbtn->hide();
        ui->standbtn->hide();
        ++playerwins;
    }
  ui->scorelbl->setText("Player " + QString::number(playerwins) +   "\n" + "Dealer " + QString::number(dealerwins));
   this->setEnabled(true);

        if (scoreplayer > 15 && scoreplayer < 22){
           ui->getcardsbtn->setEnabled(true);
        }
        else {
            ui->standbtn->hide();
            ui->playagainbtn->show();
            ui->getcardsbtn->hide();
      }

//tela de restart e quit (vitoria)
if (playerwins == 3)
{
          ui->getcardsbtn->hide();
        ui->playagainbtn->hide();
          ui->standbtn->hide();
        ui->cards->hide();
        ui->win->setPixmap(win);
        ui->resultLabel->hide();
        ui->card1Label->hide();
        ui->card2Label->hide();
        ui->card3Label->hide();
        ui->card4Label->hide();
        ui->card5Label->hide();
        ui->card6Label->hide();
        ui->card7Label->hide();
        ui->card8Label->hide();
        ui->card9Label->hide();
        ui->card10Label->hide();
        ui->scorelbl->hide();
        ui->quitbtn->show();
        ui->restartbtn->show();
        ui->dealerScoreLabel->hide();
        ui->totalLabel->hide();
        ui->win->show();
}
//tela de restart e quit (derrota)
if(dealerwins == 3)
{
    ui->getcardsbtn->hide();
    ui->playagainbtn->hide();
    ui->standbtn->hide();
    ui->cards->hide();
    ui->win->setPixmap(lose);
    ui->resultLabel->hide();
    ui->card1Label->hide();
    ui->card2Label->hide();
    ui->card3Label->hide();
    ui->card4Label->hide();
    ui->card5Label->hide();
    ui->card6Label->hide();
    ui->card7Label->hide();
    ui->card8Label->hide();
    ui->card9Label->hide();
    ui->card10Label->hide();
    ui->scorelbl->hide();
    ui->quitbtn->show();
    ui->restartbtn->show();
    ui->dealerScoreLabel->hide();
    ui->totalLabel->hide();
    ui->win->show();

}

}
void PlayWindow::on_standbtn_clicked()
{

    ui->getcardsbtn->setEnabled(false);
    ui->standbtn->setEnabled(false);

    //Generating Computer score
    dealerTurn();

}



void PlayWindow::on_playagainbtn_clicked()
{
    scoreplayer = 0;
    scoredealer = 0;
    playerCardCount = 1;
    dealerCardCount = 1;

    ui->totalLabel->setText("Total: " + QString::number(scoreplayer));
    ui->dealerScoreLabel->setText("Total: " + QString::number(scoredealer));
    ui->getcardsbtn->show();
    ui->playagainbtn->hide();
    ui->standbtn->show();
    ui->getcardsbtn->setEnabled(true);
    ui->standbtn->setEnabled(true);
    ui->resultLabel->clear();
    ui->scorelbl->setText("Player " + QString::number(playerwins) +   "\n" + "Dealer " + QString::number(dealerwins));

    // Clear nas cartas
    ui->card1Label->clear();
    ui->card2Label->clear();
    ui->card3Label->clear();
    ui->card4Label->clear();
    ui->card5Label->clear();
    ui->card6Label->clear();
    ui->card7Label->clear();
    ui->card8Label->clear();
    ui->card9Label->clear();
    ui->card10Label->clear();
}



void PlayWindow::on_quitbtn_clicked()
{
    QApplication::quit();
}


void PlayWindow::on_restartbtn_clicked()
{
    scoreplayer = 0;
    scoredealer = 0;
    playerCardCount = 1;
    dealerCardCount = 1;
    dealerwins = 0;
    playerwins = 0;
    ui->scorelbl->clear();
    ui->totalLabel->show();
    ui->dealerScoreLabel->show();
    ui->totalLabel->setText("Total: " + QString::number(scoreplayer));
    ui->dealerScoreLabel->setText("Total: " + QString::number(scoredealer));
    ui->getcardsbtn->show();
    ui->playagainbtn->hide();
    ui->standbtn->show();
    ui->getcardsbtn->setEnabled(true);
    ui->standbtn->setEnabled(true);
    ui->resultLabel->clear();
    ui->resultLabel->show();
    ui->scorelbl->show();
    ui->scorelbl->setText("Player " + QString::number(playerwins) +   "\n" + "Dealer " + QString::number(dealerwins));
    ui->win->hide();
    ui->cards->show();

    // Clear nas cartas
    ui->card1Label->clear();
    ui->card2Label->clear();
    ui->card3Label->clear();
    ui->card4Label->clear();
    ui->card5Label->clear();
    ui->card6Label->clear();
    ui->card7Label->clear();
    ui->card8Label->clear();
    ui->card9Label->clear();
    ui->card10Label->clear();

    ui->card1Label->show();
    ui->card2Label->show();
    ui->card3Label->show();
    ui->card4Label->show();
    ui->card5Label->show();
    ui->card6Label->show();
    ui->card7Label->show();
    ui->card8Label->show();
    ui->card9Label->show();
    ui->card10Label->show();

    ui->restartbtn->hide();
    ui->quitbtn->hide();
}


