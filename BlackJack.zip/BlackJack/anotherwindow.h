#ifndef ANOTHERWINDOW_H
#define ANOTHERWINDOW_H

#endif // ANOTHERWINDOW_H

#include <QMainWindow>

class AnotherWindow : public QMainWindow {
    Q_OBJECT

public:
    AnotherWindow(QWidget *parent = nullptr);
};
