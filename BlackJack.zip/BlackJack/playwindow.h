#ifndef PLAYWINDOW_H
#define PLAYWINDOW_H

#include <QDialog>


namespace Ui {
class PlayWindow;
}

class PlayWindow : public QDialog
{
    Q_OBJECT

public:
    explicit PlayWindow(QWidget *parent = 0);
    ~PlayWindow();
    QList<QPixmap> cardHolder;
    int deckValues[52];

public slots:
    void cardsList();
    void dealerTurn();

private:
    Ui::PlayWindow *ui;
private slots:

    void on_getcardsbtn_clicked();
    void on_standbtn_clicked();
    void on_playagainbtn_clicked();
    void on_quitbtn_clicked();
    void on_restartbtn_clicked();
};

#endif // PLAYWINDOW_H
