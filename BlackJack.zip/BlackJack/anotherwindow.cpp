#include "anotherwindow.h"

AnotherWindow::AnotherWindow(QWidget *parent)
    : QMainWindow(parent) {

    }
